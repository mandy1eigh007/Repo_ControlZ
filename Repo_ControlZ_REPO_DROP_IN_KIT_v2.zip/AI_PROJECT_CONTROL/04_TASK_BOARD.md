# Task Board

Keep this short. Prefer small, verifiable tasks.

## Now
- [ ] [Current task]

## Next
- [ ] [Next approved task]

## Later
- [ ] [Future task]
- [ ] [Future task]

## Done
- [x] Add repo control files

## Do Not Touch Yet
- [Feature/folder/file]
- [Feature/folder/file]
