# Current State

## Date Updated
[YYYY-MM-DD]

## Current Branch
[branch name]

## Current Goal
[What we are working on right now]

## Last Completed Task
[Last completed task]

## What Works
- [Known working item]
- [Known working item]

## What Is Broken
- [Broken item]
- [Broken item]

## Known Errors

```text
[Paste current error messages here]
```

## Next Approved Task
[Only one next task]

## Blocked Items
- [Blocked item]
- [Blocked item]

## Do Not Change During Current Task
- [File/folder/feature]
- [File/folder/feature]

## Verification Commands

```bash
git status
# add project-specific build/test commands here
```

## Notes for Next Agent Run
- [Important note]
- [Important note]
