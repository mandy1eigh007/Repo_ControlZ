# Project Brief

## Project Name
[Fill in project name]

## One-Sentence Goal
[What are we building, in one sentence?]

## Purpose
[What problem does this app/tool solve?]

## Primary Users
[Who uses it?]

## Core Workflows
1. [Workflow 1]
2. [Workflow 2]
3. [Workflow 3]

## Success Criteria
- [What must work for this to count as successful?]
- [Measurable outcome if possible]

## Non-Goals
- [What this project is not supposed to become]
- [Features or directions that are out of scope]

## Current Stack
- Frontend:
- Backend:
- Database:
- Hosting:
- Package manager:
- Other tools:

## Known Commands

```bash
# install

# dev

# build

# test
```

## Risks / Unknowns
- [Risk or unknown]
- [Risk or unknown]
