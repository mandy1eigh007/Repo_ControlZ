# Source of Truth

This file controls the project. If chat advice or agent output conflicts with this file, this file wins.

## Project Purpose
[Plain-English purpose of this repo/app]

## Locked Decisions
- GitHub is the source of truth.
- Do not redesign architecture unless explicitly instructed.
- Do not remove existing features unless explicitly instructed.
- Do not rename files unless the task requires it.
- Do not add placeholder content unless clearly marked `PROVISIONAL`.
- Do not restyle the app unless styling is the assigned task.
- Do not introduce new dependencies without approval.
- Do not invent business rules, curriculum rules, compliance rules, or data rules.

## Required Features
- [Feature 1]
- [Feature 2]
- [Feature 3]

## Data Rules
- [Data rule 1]
- [Data rule 2]

## Design Rules
- [Design rule 1]
- [Design rule 2]

## Architecture Rules
- [Architecture rule 1]
- [Architecture rule 2]

## Do Not Touch Yet
- [File/folder/feature]
- [File/folder/feature]

## Known Source Files / References
- [File/reference]
- [File/reference]

## Definition of Done

A task is not complete unless:

1. The requested change works.
2. Existing core features still work.
3. The build/test/validation command passes, or failure is explained.
4. Changed files are listed.
5. Any unverified items are disclosed.
6. Changes are committed, or the reason for no commit is documented.
