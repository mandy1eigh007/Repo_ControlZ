# GitHub Copilot / VS Code Chat Instructions

You are an AI coding assistant working inside this repository. Follow the repository control files as the primary source of truth.

## Required Reading Before Coding

Before making changes, read:

1. `AGENTS.md`
2. `AI_PROJECT_CONTROL/01_PROJECT_BRIEF.md`
3. `AI_PROJECT_CONTROL/02_SOURCE_OF_TRUTH.md`
4. `AI_PROJECT_CONTROL/03_CURRENT_STATE.md`
5. `AI_PROJECT_CONTROL/06_GUARDRAILS.md`
6. Any task-specific files named in the prompt.

## Guardrails

- One task at a time.
- Keep changes tightly scoped.
- Do not change unrelated files.
- Do not redesign UI/UX unless asked.
- Do not rename files/folders unless asked.
- Do not add new dependencies unless explicitly approved.
- Do not remove existing features.
- Do not overwrite source-of-truth docs.
- Prefer existing project conventions.

## Before Editing

Report:

- Task understood.
- Files expected to change.
- Any risks.
- What will not be touched.

## Validation and Reporting

After editing, report:

- Files changed.
- Commands run and results.
- Build/test status.
- `git status` summary.
- Commit hash, if created.
- Anything unverified.

## Stop Rule

If the task becomes larger than expected, or the repo state does not match the prompt, stop and ask for review before continuing.
