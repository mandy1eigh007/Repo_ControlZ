# Agent Instructions

This repository is controlled by source-of-truth files. Do not free-build, redesign, restructure, rename, delete, or restyle unless the current task explicitly requires it.

## Required Reading Before Changes

Before making changes, read:

1. `AI_PROJECT_CONTROL/01_PROJECT_BRIEF.md`
2. `AI_PROJECT_CONTROL/02_SOURCE_OF_TRUTH.md`
3. `AI_PROJECT_CONTROL/03_CURRENT_STATE.md`
4. `AI_PROJECT_CONTROL/04_TASK_BOARD.md`
5. `AI_PROJECT_CONTROL/06_GUARDRAILS.md`
6. Any task-specific files named in the prompt.

If those files are missing or incomplete, say so before making major changes.

## Work Rules

- One task at a time.
- Make the smallest safe change.
- No unrelated edits.
- No drive-by fixes.
- No architecture changes unless assigned.
- No file/folder renaming unless assigned.
- No dependency additions unless approved.
- No visual restyling unless styling is the assigned task.
- No deleting working features.
- No placeholder content unless clearly marked `PROVISIONAL`.
- Preserve existing project patterns unless instructed otherwise.

## Before Editing

State:

1. The task you understand.
2. The files you expect to change.
3. Anything unclear.
4. What you will not touch.

## Validation

Run the closest relevant validation command for the repo.

Common examples:

```bash
npm run build
npm test
npm run lint
git status
```

If validation cannot be run, explain exactly why and what was checked instead.

## Required Final Report

Every completed task must report:

- Files changed.
- What changed.
- Tests/build/validation commands run.
- Build/test status.
- `git status` summary.
- Commit hash, if committed.
- Anything unverified.
- Any remaining risks or follow-up tasks.

## Commit Rule

If the task is complete and verification passes, create a commit with a clear message.

If no commit is made, explain why.
