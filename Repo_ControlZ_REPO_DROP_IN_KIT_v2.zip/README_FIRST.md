# Repo ControlZ Repo Drop-In Kit

Drop these files into the root of a GitHub repo before asking AI agents to build, fix, refactor, troubleshoot, or redesign anything.

## What this kit adds

- `AGENTS.md` tells AI coding agents how to behave.
- `.github/copilot-instructions.md` gives VS Code Chat / GitHub Copilot repo-level guardrails.
- `AI_PROJECT_CONTROL/` stores the project brief, source of truth, current state, task board, worklog, and guardrails.

## How to use

1. Copy everything in this kit into the root of the target repo.
2. Fill in the blanks in:
   - `AI_PROJECT_CONTROL/01_PROJECT_BRIEF.md`
   - `AI_PROJECT_CONTROL/02_SOURCE_OF_TRUTH.md`
   - `AI_PROJECT_CONTROL/03_CURRENT_STATE.md`
3. Commit the control files before assigning app-building work.
4. Start every agent task by telling the agent to read the control files first.

## Required root layout

```text
AGENTS.md
.github/copilot-instructions.md
AI_PROJECT_CONTROL/
```

## Minimum files to fill in before agent work

- `AI_PROJECT_CONTROL/02_SOURCE_OF_TRUTH.md`
- `AI_PROJECT_CONTROL/03_CURRENT_STATE.md`
- `AGENTS.md`

Do not bury this kit inside a subfolder. It belongs at the repo root.
